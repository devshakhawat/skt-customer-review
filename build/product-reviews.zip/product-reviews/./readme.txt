=== Product Reviews ===
Contributors: devshakhawat
Requires at least: 4.5
Tested up to: 6.7
Requires PHP: 7.2
Stable tag: 1.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html
Tags: video reviews, product reviews, customer reviews

A Plugin for Extending Product Review Features, and More.

== Description ==

**Happy customers are your most effective marketers, so why not encourage them to share their experiences?**

With the Product Reviews for WooCommerce plugin, you can:

* Allow customers to capture video from webcam.
* Allow Customers to upload recorded product video review.
* Enhance standard WooCommerce reviews with advanced features to boost credibility and trust.

This plugin helps you increase engagement, build customer loyalty, improve SEO, and drive more sales with the power of social proof.

