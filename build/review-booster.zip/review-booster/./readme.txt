=== Review Booster ===
Contributors: devshakhawat
Requires at least: 5.9
Tested up to: 6.6
Requires PHP: 8.0
Stable tag: 1.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html
Tags: video review, product review, customer review

A Plugin for Product Review Showcase, and More

== Description ==